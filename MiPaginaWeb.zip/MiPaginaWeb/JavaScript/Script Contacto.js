function fInicio() {
    aplicarModoAlCargar();
}