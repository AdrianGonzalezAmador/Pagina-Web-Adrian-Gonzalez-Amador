function fInicio() {
        aplicarModoAlCargar();
    }